
import './App.css'
import TestComponent from './component/TestComponent'
import User from './component/User'
import Calculator from './page/Calculator'

function App() {


  return (
    <>
      {/* <TestComponent />
      <Calculator /> */}
      <User />
    </>
  )
}

export default App
