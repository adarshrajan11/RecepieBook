import React from 'react';
import TestComponent from './TestComponent';




const Parent = () => {
    const v1 = 1;
    const v2 = 2;
    return (

        <div>
            <TestComponent num1={v1} num2={v2} />
        </div>
    );
};

export default Parent;